### Exercise 2

**a) List and explain the sequence of calls performed by the program in x86-64/prog.s**

----



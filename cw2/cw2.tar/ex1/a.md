### Exercise 1

**a) Consider Figures 5-18 through 5-23. What changes would need to be made to these figures if the architectural limit for physical memory were to be increased to 64 PB?**

----

<!-- Write your answer here, along with the reasoning behind it. -->

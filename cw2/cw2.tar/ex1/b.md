### Exercise 1

**b) Suppose AMD wants to support virtual address spaces of 512 PB. What changes would need to be made to Figure 5.18? How many different "Page-Map Level-5" tables could then exist for a single process? Read sections 1.1.3 and 5.3.1 and indicate the ranges of canonical addresses for the proposed extension.
**

----

**Changes to be made to Figure 5.18**

<!-- Write your answer here, along with the reasoning behind it. -->


**Maximum number of "Page-Map Level-5" tables per process**

<!-- Write your answer here, along with the reasoning behind it. -->


**Ranges of canonical addresses**

<!-- Write your answer here, along with the reasoning behind it. -->

